 * Website: http://ithemes.com/purchase/backupbuddy/
 *
 * Installation:
 * 
 * 1. Download and unzip the latest release zip file
 * 2. If you use the WordPress plugin uploader to install this plugin skip to step 4.
 * 3. Upload the entire plugin directory to your `/wp-content/plugins/` directory
 * 4. Activate the plugin through the 'Plugins' menu in WordPress Administration
 * 
 * Usage:
 * 
 * 1. Navigate to the new menu for this plugin in the Wordpress Administration Panel
 * 2. Select 'Getting Started' for instructions and additional information.
 *